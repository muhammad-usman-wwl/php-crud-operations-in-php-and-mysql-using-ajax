<?php
// config/Database.php
// Database connection class using PDO (PHP Data Objects).
// PDO lets us use prepared statements, which protect against SQL injection.

class Database
{
    private string $host = "localhost";
    private string $dbName = "crud_ajax_db";
    private string $username = "root";
    private string $password = "";
    private ?PDO $connection = null;

    // Returns a PDO connection, creating it only once.
    public function getConnection(): PDO
    {
        if ($this->connection !== null) {
            return $this->connection;
        }

        $dsn = "mysql:host={$this->host};dbname={$this->dbName};charset=utf8mb4";

        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false, // real prepared statements
        ];

        $this->connection = new PDO($dsn, $this->username, $this->password, $options);
        return $this->connection;
    }
}
