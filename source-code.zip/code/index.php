<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Manager — PHP CRUD with AJAX</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container py-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 mb-0">Student Manager</h1>
        <button class="btn btn-primary" id="btnAdd">+ Add Student</button>
    </div>

    <div class="card shadow-sm">
        <div class="card-body">
            <div class="row mb-3">
                <div class="col-md-6">
                    <input type="text" id="searchInput" class="form-control"
                           placeholder="Search by name, email or course...">
                </div>
            </div>

            <div id="alertBox"></div>

            <table class="table table-striped table-hover align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Course</th>
                        <th width="170">Actions</th>
                    </tr>
                </thead>
                <tbody id="studentTable">
                    <!-- Rows are loaded here by AJAX -->
                </tbody>
            </table>
            <p class="text-muted mb-0"><span id="recordCount">0</span> record(s)</p>
        </div>
    </div>
</div>

<!-- Add / Edit Modal -->
<div class="modal fade" id="studentModal" tabindex="-1">
    <div class="modal-dialog">
        <form id="studentForm">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalTitle">Add Student</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="studentId">
                    <div class="mb-3">
                        <label class="form-label">Name</label>
                        <input type="text" id="name" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" id="email" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Course</label>
                        <input type="text" id="course" class="form-control" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" id="btnSave">Save Student</button>
                </div>
            </div>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script>
const modal = new bootstrap.Modal(document.getElementById('studentModal'));

function showAlert(message, type = 'success') {
    $('#alertBox').html(
        `<div class="alert alert-${type} alert-dismissible fade show" role="alert">
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>`
    );
}

// READ — load all students into the table, without refreshing the page
function loadStudents(search = '') {
    $.getJSON('api/read.php', { search: search }, function (response) {
        let rows = '';
        response.data.forEach(function (s, index) {
            rows += `<tr>
                <td>${index + 1}</td>
                <td>${s.name}</td>
                <td>${s.email}</td>
                <td>${s.course}</td>
                <td>
                    <button class="btn btn-sm btn-warning btn-edit" data-id="${s.id}">Edit</button>
                    <button class="btn btn-sm btn-danger btn-delete" data-id="${s.id}">Delete</button>
                </td>
            </tr>`;
        });
        if (response.count === 0) {
            rows = '<tr><td colspan="5" class="text-center text-muted">No students found.</td></tr>';
        }
        $('#studentTable').html(rows);
        $('#recordCount').text(response.count);
    });
}

// Open the modal for CREATE
$('#btnAdd').on('click', function () {
    $('#studentForm')[0].reset();
    $('#studentId').val('');
    $('#modalTitle').text('Add Student');
    modal.show();
});

// Open the modal for UPDATE — first fetch the current values
$(document).on('click', '.btn-edit', function () {
    const id = $(this).data('id');
    $.getJSON('api/read.php', { id: id }, function (response) {
        const s = response.data;
        $('#studentId').val(s.id);
        $('#name').val(s.name);
        $('#email').val(s.email);
        $('#course').val(s.course);
        $('#modalTitle').text('Edit Student');
        modal.show();
    });
});

// CREATE or UPDATE — one form, the hidden id decides which one
$('#studentForm').on('submit', function (e) {
    e.preventDefault();
    const id = $('#studentId').val();
    const url = id ? 'api/update.php' : 'api/create.php';
    const data = {
        id: id,
        name: $('#name').val(),
        email: $('#email').val(),
        course: $('#course').val()
    };
    $.post(url, data, function (response) {
        showAlert(response.message, 'success');
        modal.hide();
        loadStudents($('#searchInput').val()); // refresh the table only
    }, 'json').fail(function (xhr) {
        const res = xhr.responseJSON;
        showAlert(res ? res.message : 'Something went wrong.', 'danger');
    });
});

// DELETE — ask first, then remove the row without a refresh
$(document).on('click', '.btn-delete', function () {
    const id = $(this).data('id');
    if (!confirm('Are you sure you want to delete this student?')) return;
    $.post('api/delete.php', { id: id }, function (response) {
        showAlert(response.message, 'success');
        loadStudents($('#searchInput').val());
    }, 'json').fail(function (xhr) {
        const res = xhr.responseJSON;
        showAlert(res ? res.message : 'Something went wrong.', 'danger');
    });
});

// LIVE SEARCH — filter as you type
$('#searchInput').on('keyup', function () {
    loadStudents($(this).val());
});

// First load
loadStudents();
</script>
</body>
</html>
