<?php
// models/Student.php
// Student model: all database operations for the "students" table.
// Every query uses prepared statements with bound parameters,
// so user input can never change the SQL itself.

class Student
{
    private PDO $conn;
    private string $table = "students";

    public int $id;
    public string $name;
    public string $email;
    public string $course;

    public function __construct(PDO $db)
    {
        $this->conn = $db;
    }

    // CREATE — insert a new student. Returns true on success.
    public function create(): bool
    {
        $query = "INSERT INTO {$this->table} (name, email, course)
                  VALUES (:name, :email, :course)";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":name", $this->name);
        $stmt->bindParam(":email", $this->email);
        $stmt->bindParam(":course", $this->course);

        if ($stmt->execute()) {
            $this->id = (int) $this->conn->lastInsertId();
            return true;
        }
        return false;
    }

    // READ ALL — returns every student, newest first.
    // An optional search term filters by name, email or course.
    public function readAll(string $search = ""): array
    {
        if ($search !== "") {
            // Note: with real (non-emulated) prepared statements, each
            // placeholder name may appear only once, so we use three names
            // and bind the same value to each of them.
            $query = "SELECT id, name, email, course, created_at
                      FROM {$this->table}
                      WHERE name LIKE :search_name OR email LIKE :search_email OR course LIKE :search_course
                      ORDER BY id DESC";
            $stmt = $this->conn->prepare($query);
            $like = "%" . $search . "%";
            $stmt->bindParam(":search_name", $like);
            $stmt->bindParam(":search_email", $like);
            $stmt->bindParam(":search_course", $like);
        } else {
            $query = "SELECT id, name, email, course, created_at
                      FROM {$this->table}
                      ORDER BY id DESC";
            $stmt = $this->conn->prepare($query);
        }

        $stmt->execute();
        return $stmt->fetchAll();
    }

    // READ ONE — returns a single student by id, or null if not found.
    public function readOne(int $id): ?array
    {
        $query = "SELECT id, name, email, course, created_at
                  FROM {$this->table}
                  WHERE id = :id
                  LIMIT 1";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id, PDO::PARAM_INT);
        $stmt->execute();

        $row = $stmt->fetch();
        return $row === false ? null : $row;
    }

    // UPDATE — change an existing student.
    public function update(): bool
    {
        $query = "UPDATE {$this->table}
                  SET name = :name, email = :email, course = :course
                  WHERE id = :id";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":name", $this->name);
        $stmt->bindParam(":email", $this->email);
        $stmt->bindParam(":course", $this->course);
        $stmt->bindParam(":id", $this->id, PDO::PARAM_INT);

        return $stmt->execute();
    }

    // DELETE — remove a student by id.
    public function delete(): bool
    {
        $query = "DELETE FROM {$this->table} WHERE id = :id";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $this->id, PDO::PARAM_INT);

        return $stmt->execute() && $stmt->rowCount() > 0;
    }
}
