-- database.sql
-- PHP CRUD with AJAX and MySQL — Simplified Dev Code Camp
-- Import this file in phpMyAdmin, or run:  mysql -u root < database.sql

CREATE DATABASE IF NOT EXISTS crud_ajax_db
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE crud_ajax_db;

CREATE TABLE IF NOT EXISTS students (
    id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name       VARCHAR(100) NOT NULL,
    email      VARCHAR(150) NOT NULL UNIQUE,
    course     VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO students (name, email, course) VALUES
    ('Ali Khan',    'ali.khan@example.com',    'PHP & MySQL'),
    ('Sara Ahmed',  'sara.ahmed@example.com',  'JavaScript'),
    ('John Mathew', 'john.mathew@example.com', 'WordPress'),
    ('Fatima Noor', 'fatima.noor@example.com', 'Laravel');
