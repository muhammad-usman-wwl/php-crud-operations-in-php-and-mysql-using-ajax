<?php
// api/read.php — GET: optional ?id=5 for one record, ?search=term to filter
header("Content-Type: application/json");

require_once __DIR__ . "/../config/Database.php";
require_once __DIR__ . "/../models/Student.php";

try {
    $db = (new Database())->getConnection();
    $student = new Student($db);

    if (isset($_GET["id"])) {
        $row = $student->readOne((int) $_GET["id"]);
        if ($row === null) {
            http_response_code(404);
            echo json_encode(["status" => "error", "message" => "Student not found."]);
        } else {
            echo json_encode(["status" => "success", "data" => $row]);
        }
        exit;
    }

    $search = trim($_GET["search"] ?? "");
    $rows = $student->readAll($search);
    echo json_encode(["status" => "success", "count" => count($rows), "data" => $rows]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Database error."]);
}
