<?php
// api/update.php — POST: id, name, email, course  →  JSON result
header("Content-Type: application/json");

require_once __DIR__ . "/../config/Database.php";
require_once __DIR__ . "/../models/Student.php";

$id     = (int) ($_POST["id"] ?? 0);
$name   = trim($_POST["name"] ?? "");
$email  = trim($_POST["email"] ?? "");
$course = trim($_POST["course"] ?? "");

if ($id <= 0 || $name === "" || $email === "" || $course === "") {
    http_response_code(422);
    echo json_encode(["status" => "error", "message" => "All fields are required."]);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(422);
    echo json_encode(["status" => "error", "message" => "Please enter a valid email address."]);
    exit;
}

try {
    $db = (new Database())->getConnection();
    $student = new Student($db);

    if ($student->readOne($id) === null) {
        http_response_code(404);
        echo json_encode(["status" => "error", "message" => "Student not found."]);
        exit;
    }

    $student->id = $id;
    $student->name = $name;
    $student->email = $email;
    $student->course = $course;

    if ($student->update()) {
        echo json_encode(["status" => "success", "message" => "Student updated successfully."]);
    } else {
        http_response_code(500);
        echo json_encode(["status" => "error", "message" => "Could not update the student."]);
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Database error."]);
}
