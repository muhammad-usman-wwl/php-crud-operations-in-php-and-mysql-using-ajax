<?php
// api/delete.php — POST: id  →  JSON result
header("Content-Type: application/json");

require_once __DIR__ . "/../config/Database.php";
require_once __DIR__ . "/../models/Student.php";

$id = (int) ($_POST["id"] ?? 0);

if ($id <= 0) {
    http_response_code(422);
    echo json_encode(["status" => "error", "message" => "A valid student id is required."]);
    exit;
}

try {
    $db = (new Database())->getConnection();
    $student = new Student($db);
    $student->id = $id;

    if ($student->delete()) {
        echo json_encode(["status" => "success", "message" => "Student deleted successfully."]);
    } else {
        http_response_code(404);
        echo json_encode(["status" => "error", "message" => "Student not found."]);
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Database error."]);
}
